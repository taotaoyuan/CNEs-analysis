This directory has the following structure
|---CleanData	Scripts for filtering low-quality reads, correcting sequencing errors and connecting 170bp insertSize paired-end reads
|---SOAPdenovo	Scripts for genome assembly using SOAPdenovo
|---GapCloser	Scripts for filling gaps betweeen scaffold
