perl ./krskgf/krskgf.pl --contig /currentDIR/species.scafSeq.SCAF.contig --gapread /currentDIR/gapread.fa --outdir /currentDIR/  --step 23 --vf=800m --cpu 10 >fill_step23.log &
