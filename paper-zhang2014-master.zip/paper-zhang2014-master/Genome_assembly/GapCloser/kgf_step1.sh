perl krskgf/krskgf.pl --scaf ../SOAPdenovo/species.scafSeq --lib /currentDIR/kgf.cfg --outdir /currentDIR/ --step 1 >fill_step1.log
