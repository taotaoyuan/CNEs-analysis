./GapCloser_v1.10 -a species.scafSeq.fill -b gapCloser.cfg -o species.scafSeq.fill.FG -t 24
