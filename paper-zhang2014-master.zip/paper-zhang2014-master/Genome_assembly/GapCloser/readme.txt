Files in this directory:

(1) kgf_step1.sh
	The first step of gap filling using 'kgf' software
(2) kgf_step23.sh
	The second and third step of gap filling using 'kgf' software
(3) gapCloser.sh
	Filling gaps bwtween scaffolds using 'gapCloser' software by inputting gapfilling result of 'kgf'.
(4) kgf.cfg; gapCloser.cfg
	The config files of 'kgf' and 'GapCloser' software, respectively
