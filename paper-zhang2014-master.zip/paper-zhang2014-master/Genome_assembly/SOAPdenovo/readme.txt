Files in this directory

(1) SOAPdenovo.sh
	Command details of SOAPdenovo
(2) SOAPdenovo.cfg
	SOAPdenovo configuration file
