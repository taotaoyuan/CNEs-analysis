nohup perl ./run_filter.pl lane_all.lst insertSize.txt &
