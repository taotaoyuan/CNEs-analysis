Files in this directory:

(1) FilterReads.sh
	Filtering low-quality reads and PCR duplication reads
(2) Correct.sh
	Correcting sequencing errors based on 17-mer frequency methodology
(3) cmr.sh
	Connecting pair-end reads of insertSize 170bp to facilitate gap filling 
