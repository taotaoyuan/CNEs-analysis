./kmer_freq -k 17 -p species correct.lst
./correct_error_pread -k 17 -l 13 -t 6 species.freq.cz correct.lst
