prediction_step1.sh was used to do rough alignment and precise alignment by using BLAST and Genewise.

prediction_step2.sh was used to generate integrated gene set by combining prediction results.
