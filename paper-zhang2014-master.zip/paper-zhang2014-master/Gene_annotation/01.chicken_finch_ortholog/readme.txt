ortholog.step1.sh was used to generate candidate orthologs between chicken (GALGA) and finch (TAEGU) based on genome synteny.

ortholog.step2.sh was used to produce orthologs through filterring out ambigous orthologs.
