date
perl ../bin/00.Main.pl inputData/config/species.list Orthologous_Syntenic_Blocks/ inputData/gff inputData/config/species.list.div
date
