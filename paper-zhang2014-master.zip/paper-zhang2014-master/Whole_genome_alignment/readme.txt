The 'pairwise/' directory contains the pipeline for generating pairwise genome
alignment of two avian genomes.

The 'multiple/' directory contains the pipeline for generating multiple genome
alignment of 48 birds.
